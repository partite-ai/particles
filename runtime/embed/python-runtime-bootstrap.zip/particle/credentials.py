"""Credentials access for Python particles.

The substitution-based credential types (basic, oauth2, apikey) never
hand their actual value to Python — `get_placeholder(name)` returns
an opaque placeholder string + an apply-spec describing where the
host expects to substitute it. User code typically goes through
`particle.http.fetch(..., credential_name=name)` instead of calling
`get_placeholder` directly; fetch applies the placeholder to the
right location and the host substitutes when the request leaves
wasm.

`get_raw(name)` returns the actual value — only valid for type-`raw`
credentials, where the manifest explicitly opted into raw access.
"""

from dataclasses import dataclass
from enum import Enum
from typing import Optional

import _runtime_host

__all__ = [
    "ApplyKind",
    "ApplySpec",
    "PlaceholderInfo",
    "get_placeholder",
    "get_raw",
    "get_configured_method",
    "is_configured",
]


class ApplyKind(str, Enum):
    BASIC = "basic"
    BEARER = "bearer"
    HEADER = "header"
    AUTH_SCHEME = "auth-scheme"
    QUERY_PARAM = "query-param"


@dataclass
class ApplySpec:
    """Tells the host where a placeholder should appear in an outbound
    HTTP request. Matches `particle:host/credentials.apply-spec`."""
    kind: ApplyKind
    name: Optional[str] = None
    scheme: Optional[str] = None


@dataclass
class PlaceholderInfo:
    placeholder: str
    apply: ApplySpec


def get_placeholder(name: str) -> PlaceholderInfo:
    """Issue an opaque placeholder for credential `name`.

    The host expects the placeholder to appear at the location
    described by `apply`; placing it anywhere else means the request
    transmits the literal placeholder (and the server rejects it) —
    a security-by-design choice, see design doc §7.
    """
    info = _runtime_host._credentials_get_placeholder(name)
    apply = info["apply"]
    return PlaceholderInfo(
        placeholder=info["placeholder"],
        apply=ApplySpec(
            kind=ApplyKind(apply["kind"]),
            name=apply.get("name"),
            scheme=apply.get("scheme"),
        ),
    )


def get_raw(name: str) -> str:
    """Return the actual value of a `type: "raw"` credential.

    Only valid for credentials the manifest declared as type `raw`.
    Other types raise a host-side type-mismatch error.
    """
    return _runtime_host._credentials_get_raw(name)


def get_configured_method(name: str) -> Optional[str]:
    """Return the method name (e.g. "pat", "oauth") the user picked
    at setup for `name`, or None if no method is configured.
    """
    return _runtime_host._credentials_get_configured_method(name)


def is_configured(name: str) -> bool:
    """Convenience: True iff `name` has any method configured."""
    return _runtime_host._credentials_is_configured(name)
